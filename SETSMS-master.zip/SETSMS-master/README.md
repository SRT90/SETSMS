# SETSMS
Conjunto de Herramientas para Spam de SMS.
#
# INSTALACIÓN
#
chmod 711 install.sh
#
./install.sh
#
# USO
#
./SETSMS.sh
#
# Created by: Informatic_in_Termux
