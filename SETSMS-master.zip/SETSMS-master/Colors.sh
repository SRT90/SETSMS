# Colores Bash
#
export rosa='\033[38;5;207m'
export rojo='\033[31m'
export verde='\033[32m'
export amarillo='\033[33m'
export azul='\033[34m'
export morado='\033[35m'
export blanco='\033[37m'
export cyan='\033[1;36m'
export magenta='\033[1;35m'
export negro='\033[0;30m'
export gris_oscuro='\033[1;30'
